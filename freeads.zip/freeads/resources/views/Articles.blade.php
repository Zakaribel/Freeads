@extends('layouts.app')

@section('content')



<div class="container">

    <div class="row justify-content-center">
        <div class="col-md-8">

            @if ($annonces->count())
            @foreach($annonces as $key => $value)

            <div class="card" style="margin: 30px; padding: 15px;">
                <p> <b> Author :</b> {{$value->user->name}}</p>


                <div class="card">
                <label style="text-align: center;"><b> Title :</b> {{$value->title}} </label>
                </div>

                <div class="card">
                <label style="height: 100px;margin-top:1%;text-align:center"><b> Description :</b> <br><br> {{$value->description}} </label>
                </div>
                
                <div class="card">
                <label style="text-align: right;margin-right:2%;"><b> Price :</b> {{$value->price}} </label>
                </div>

            </div>

            @endforeach

            @else

            <p>No articles published yet.</p>

            @endif

        </div>
    </div>
</div>

</div>

@endsection