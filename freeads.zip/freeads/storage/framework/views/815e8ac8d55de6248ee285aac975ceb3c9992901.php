<?php $__env->startSection('content'); ?>

<?php if(session()->has('success')): ?>
    <div class="alert alert-success" style="text-align: center;">
        <?php echo e(session()->get('success')); ?>

    </div>
    <?php endif; ?>
    
<div class="container">

        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">

                    <form action="" method="POST" enctype="multipart/form-data">

                        <?php echo csrf_field(); ?>

                        <input type="text" name="title" required placeholder="Title "><br><br>
                        <label><b>Photo :</b> </label>
                        <input type="file"  name="photo">
                        <input type="textarea" name="description" required placeholder="Descritpion" size="50"><br><br>
                        <input type="text" name="price" required placeholder="Price (€)"><br><br>

                        <input type="submit" value="Submit your article">

                    </form>

                </div>
            </div>
        </div>
</div>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zak/Desktop/W-PHP-502-NAN-2-1-FreeAds-zakaria.belkacemi/freeads/resources/views/createArticle.blade.php ENDPATH**/ ?>