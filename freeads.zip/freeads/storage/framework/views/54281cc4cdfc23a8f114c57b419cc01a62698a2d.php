<?php $__env->startSection('content'); ?>

<div class="container">

        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">

                    <form action="" method="POST">

                        <?php echo csrf_field(); ?>

                        <input type="text" name="title" required placeholder="Title of your post"><br><br>
                        <input type="textarea" name="description" required placeholder="Descritpion of your post" size="50"><br><br>
                        <input type="text" name="price" required placeholder="Price (€)"><br><br>

                        <input type="submit" value="Submit your post">

                    </form>

                </div>
            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zak/Desktop/W-PHP-502-NAN-2-1-FreeAds-zakaria.belkacemi/freeads/resources/views/createPost.blade.php ENDPATH**/ ?>