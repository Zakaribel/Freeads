<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/zak/Desktop/W-PHP-502-NAN-2-1-FreeAds-zakaria.belkacemi/freeads/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>