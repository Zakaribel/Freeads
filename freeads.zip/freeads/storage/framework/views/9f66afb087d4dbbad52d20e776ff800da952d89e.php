<?php $__env->startSection('content'); ?>



<div class="container">

    <div class="row justify-content-center">
        <div class="col-md-8">

            <?php if($annonces->count()): ?>
            <?php $__currentLoopData = $annonces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="card" style="margin: 30px; padding: 15px;">
                <p> <b> Author :</b> <?php echo e($value->user->name); ?></p>


                <div class="card">
                <label style="text-align: center;"><b> Title :</b> <?php echo e($value->title); ?> </label>
                </div>

                <div class="card">
                <label style="height: 100px;margin-top:1%;text-align:center"><b> Description :</b> <br><br> <?php echo e($value->description); ?> </label>
                </div>
                
                <div class="card">
                <label style="text-align: right;margin-right:2%;"><b> Price :</b> <?php echo e($value->price); ?> </label>
                </div>

            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php else: ?>

            <p>No articles published yet.</p>

            <?php endif; ?>

        </div>
    </div>
</div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zak/Desktop/W-PHP-502-NAN-2-1-FreeAds-zakaria.belkacemi/freeads/resources/views/Articles.blade.php ENDPATH**/ ?>