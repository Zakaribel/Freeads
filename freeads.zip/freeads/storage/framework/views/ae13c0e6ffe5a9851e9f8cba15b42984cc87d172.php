<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
</head>
<body>

<?php if(Session::has('success')): ?>
<div>
<?php echo e(Session::get('success')); ?>

</div>
<?php endif; ?>

<form  method="post" action="/register">

<?php echo csrf_field(); ?> 


<label>Name</label>
<input type="text" name="name" required>
<label>Email</label>
<input type="email" name="email" required>
<label>Password</label>
<input type="password" name="password" required>

<input type="submit" name="send" value="Submit">



</form>


    
</body>
</html><?php /**PATH /home/zak/Desktop/W-PHP-502-NAN-2-1-FreeAds-zakaria.belkacemi/freeads/resources/views/register.blade.php ENDPATH**/ ?>