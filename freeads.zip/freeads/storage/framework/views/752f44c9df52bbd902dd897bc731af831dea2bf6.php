<?php echo e($slot); ?>

<?php /**PATH /home/zak/Desktop/W-PHP-502-NAN-2-1-FreeAds-zakaria.belkacemi/freeads/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>