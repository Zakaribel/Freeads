<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Annonce;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class AnnoncesController extends Controller
{
    
public function createArticle(){

    return view('createArticle');
}


public function articleForm(Request $request){

  var_dump("KZKW",  move_uploaded_file($_FILES['photo']['name'], base_path('/img')));
  
    Annonce::create([
        'title' =>request('title'),
        'description' => request('description'),
        'price' => request('price'),
        'photo' => request('photo'),
        'user_id' => Auth::id()
    ]);
    return redirect(route('createArticle'))->
    with('success','Article successfully created');

}




 



}
