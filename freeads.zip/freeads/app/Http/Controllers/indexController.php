<?php

class indexController{


    public function showIndex(){

            return view('index');

    }


}